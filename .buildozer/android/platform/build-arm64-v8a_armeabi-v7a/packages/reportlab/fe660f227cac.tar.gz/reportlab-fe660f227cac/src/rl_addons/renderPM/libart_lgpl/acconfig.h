#undef PACKAGE
#undef VERSION
